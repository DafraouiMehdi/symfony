<?php

namespace App\Entity;

use App\Repository\RendezVRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: RendezVRepository::class)]
class RendezV
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private ?\DateTimeInterface $date_rv = null;

    #[ORM\ManyToOne(inversedBy: 'rendezVs')]
    private ?Patient $patient = null;

    #[ORM\ManyToOne(inversedBy: 'rendezVs')]
    private ?Medecin $madecin = null;

    #[ORM\ManyToOne(inversedBy: 'rendezVs')]
    private ?Secretaire $secretaire = null;


    /**
     * @ORM\Column(type="string", length=50)
     */
    private $status;

    // Getter for status
    public function getStatus(): ?string
    {
        return $this->status;
    }

    // Setter for status
    public function setStatus(string $status): self
    {
        $this->status = $status;

        return $this;
    }
    
    public function getId(): ?int
    {
        return $this->id;
    }

    public function setId(int $id): static
    {
        $this->id = $id;

        return $this;
    }

    public function getDateRv(): ?\DateTimeInterface
    {
        return $this->date_rv;
    }

    public function setDateRv(\DateTimeInterface $date_rv): static
    {
        $this->date_rv = $date_rv;

        return $this;
    }

    public function getPatient(): ?Patient
    {
        return $this->patient;
    }

    public function setPatient(?Patient $patient): static
    {
        $this->patient = $patient;

        return $this;
    }

    public function getMadecin(): ?Medecin
    {
        return $this->madecin;
    }

    public function setMadecin(?Medecin $madecin): static
    {
        $this->madecin = $madecin;

        return $this;
    }

    public function getSecretaire(): ?Secretaire
    {
        return $this->secretaire;
    }

    public function setSecretaire(?Secretaire $secretaire): static
    {
        $this->secretaire = $secretaire;

        return $this;
    }
}
