<?php

namespace App\Entity;

use App\Repository\AcceptableRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: AcceptableRepository::class)]
class Acceptable
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $patientname = null;

    #[ORM\Column(length: 255)]
    private ?string $medecinname = null;

    #[ORM\Column(type: Types::DATE_MUTABLE)]
    private ?\DateTimeInterface $rendezvousdate = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getPatientname(): ?string
    {
        return $this->patientname;
    }

    public function setPatientname(string $patientname): static
    {
        $this->patientname = $patientname;

        return $this;
    }

    public function getMedecinname(): ?string
    {
        return $this->medecinname;
    }

    public function setMedecinname(string $medecinname): static
    {
        $this->medecinname = $medecinname;

        return $this;
    }

    public function getRendezvousdate(): ?\DateTimeInterface
    {
        return $this->rendezvousdate;
    }

    public function setRendezvousdate(\DateTimeInterface $rendezvousdate): static
    {
        $this->rendezvousdate = $rendezvousdate;

        return $this;
    }
}
