<?php

namespace App\Entity;

use App\Repository\PatientRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: PatientRepository::class)]
class Patient
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $name = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private ?\DateTimeInterface $date_naiss = null;

    #[ORM\Column(length: 255)]
    private ?string $email = null;

    #[ORM\Column(length: 255)]
    private ?string $password = null;

    #[ORM\Column(length: 255)]
    private ?string $tele = null;

    /**
     * @var Collection<int, RendezV>
     */
    #[ORM\OneToMany(targetEntity: RendezV::class, mappedBy: 'patient')]
    private Collection $rendezVs;

    /**
     * @var Collection<int, DossierMedical>
     */
    #[ORM\OneToMany(targetEntity: DossierMedical::class, mappedBy: 'patient')]
    private Collection $dossierMedicals;

    public function __construct()
    {
        $this->rendezVs = new ArrayCollection();
        $this->dossierMedicals = new ArrayCollection();
    }

    

    public function getId(): ?int
    {
        return $this->id;
    }

    public function setId(int $id): static
    {
        $this->id = $id;

        return $this;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    public function getDateNaiss(): ?\DateTimeInterface
    {
        return $this->date_naiss;
    }

    public function setDateNaiss(\DateTimeInterface $date_naiss): static
    {
        $this->date_naiss = $date_naiss;

        return $this;
    }

    public function getEmail(): ?string
    {
        return $this->email;
    }

    public function setEmail(string $email): static
    {
        $this->email = $email;

        return $this;
    }

    public function getPassword(): ?string
    {
        return $this->password;
    }

    public function setPassword(string $password): static
    {
        $this->password = $password;

        return $this;
    }

    public function getTele(): ?string
    {
        return $this->tele;
    }

    public function setTele(string $tele): static
    {
        $this->tele = $tele;

        return $this;
    }

    /**
     * @return Collection<int, RendezV>
     */
    public function getRendezVs(): Collection
    {
        return $this->rendezVs;
    }

    public function addRendezV(RendezV $rendezV): static
    {
        if (!$this->rendezVs->contains($rendezV)) {
            $this->rendezVs->add($rendezV);
            $rendezV->setPatient($this);
        }

        return $this;
    }

    public function removeRendezV(RendezV $rendezV): static
    {
        if ($this->rendezVs->removeElement($rendezV)) {
            // set the owning side to null (unless already changed)
            if ($rendezV->getPatient() === $this) {
                $rendezV->setPatient(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, DossierMedical>
     */
    public function getDossierMedicals(): Collection
    {
        return $this->dossierMedicals;
    }

    public function addDossierMedical(DossierMedical $dossierMedical): static
    {
        if (!$this->dossierMedicals->contains($dossierMedical)) {
            $this->dossierMedicals->add($dossierMedical);
            $dossierMedical->setPatient($this);
        }

        return $this;
    }

    public function removeDossierMedical(DossierMedical $dossierMedical): static
    {
        if ($this->dossierMedicals->removeElement($dossierMedical)) {
            // set the owning side to null (unless already changed)
            if ($dossierMedical->getPatient() === $this) {
                $dossierMedical->setPatient(null);
            }
        }

        return $this;
    }   
}
