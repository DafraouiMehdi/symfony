<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Doctrine\ORM\EntityManagerInterface;
use App\Entity\Acceptable;

final class AcceptableController extends AbstractController{
    private $entityManager;
    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }
    #[Route('/acceptables/{medecinname}', name: 'acceptables_list', methods: ['GET'])]
    public function listAcceptables(string $medecinname): Response
    {
        // Récupération des acceptables depuis la base de données
        $acceptables = $this->entityManager->getRepository(Acceptable::class)->findBy(['medecinname' => $medecinname]);
    
        // Vérification si des acceptables existent
        if (!$acceptables) {
            throw $this->createNotFoundException('Aucun rendez-vous trouvé pour ce médecin.');
        }
    
        // Rendu du tableau avec les données
        return $this->render('acceptable/liste.html.twig', [
            'acceptables' => $acceptables,
        ]);
    }
    

    
    #[Route('/acceptable/delete/{id}', name: 'acceptable_delete', methods: ['POST'])]
    public function deleteAcceptable(int $id): Response
    {
        // Récupération de l'acceptable par son ID
        $acceptable = $this->entityManager->getRepository(Acceptable::class)->find($id);
        
        if ($acceptable) {
            $medecinname = $acceptable->getMedecinname(); // Assurez-vous d'avoir cette méthode
            $this->entityManager->remove($acceptable);
            $this->entityManager->flush();
        
            $this->addFlash('success', 'Rendez-vous supprimé avec succès.');
        } else {
            $this->addFlash('error', 'Rendez-vous introuvable.');
        }
        
        // Redirection vers la liste des acceptables avec le nom du médecin
        return $this->redirectToRoute('acceptables_list', ['medecinname' => $medecinname]);
    }
    
}
