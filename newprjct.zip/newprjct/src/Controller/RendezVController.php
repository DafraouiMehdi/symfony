<?php

namespace App\Controller;

use App\Entity\Patient;
use App\Entity\Medecin;
use App\Entity\Secretaire;
use App\Entity\RendezV;
use App\Form\RendezVType;
use App\Repository\RendezVRepository; 
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

#[Route('/rendez/v', name: 'app_rendezv_')]
final class RendezVController extends AbstractController{
    #[Route(name: 'app_rendez_v_index', methods: ['GET'])]
    public function index(RendezVRepository $rendezVRepository): Response
    {
        return $this->render('rendez_v/index.html.twig', [
            'rendez_vs' => $rendezVRepository->findAll(),
        ]);
    }

    #[Route('new/{id}', name: 'new', methods: ['GET', 'POST'])]
    public function new(Request $request, EntityManagerInterface $entityManager, $id): Response
    {
        // Retrieve the patient using the passed ID
        $patient = $entityManager->getRepository(Patient::class)->find($id);
        
        // If the patient does not exist, redirect to an error page or index
        if (!$patient) {
            throw $this->createNotFoundException('No patient found for id ' . $id);
        }

        // Fetch all doctors and secretaries for the form
        $doctors = $entityManager->getRepository(Medecin::class)->findAll();
        $secretairas = $entityManager->getRepository(Secretaire::class)->findAll();

        // Create a new RendezV object
        $rendezV = new RendezV();

        // Handle form submission
        if ($request->isMethod('POST')) {
            // Get the form data
            $doctorId = $request->request->get('doctor');
            $date = $request->request->get('date');
            $secretaireId = $request->request->get('secretaire');

            // Fetch the selected doctor and secretaire
            $doctor = $entityManager->getRepository(Medecin::class)->find($doctorId);
            $secretaire = $entityManager->getRepository(Secretaire::class)->find($secretaireId);

            // Set the properties of the RendezV object
            $rendezV->setPatient($patient);
            $rendezV->setMadecin($doctor);
            $rendezV->setSecretaire($secretaire);
            $rendezV->setDateRv(new \DateTime($date)); // Ensure date is properly formatted

            // Persist the new RendezV
            $entityManager->persist($rendezV);
            $entityManager->flush();

            // Redirect to the referer URL
            return $this->render("success.html.twig"); // Redirect back
        }

        // Render the form for creating a new RendezV
        return $this->render('rendez_v/new.html.twig', [
            'rendez_v' => $rendezV,
            'doctors' => $doctors,
            'secretairas' => $secretairas,
            'patient_id' => $id, // Pass patient ID for the form action
        ]);
    }


    // #[Route('/{id}', name: 'app_rendez_v_show', methods: ['GET'])]
    // public function show(RendezV $rendezV): Response
    // {
    //     return $this->render('rendez_v/show.html.twig', [
    //         'rendez_v' => $rendezV,
    //     ]);
    // }

    // #[Route('/getAll/{id}', name: 'app_rendez_v_show', methods: ['GET'])]
    // public function show(int $id, EntityManagerInterface $entityManager): Response
    // {
    //     // Retrieve the patient based on the ID
    //     $patient = $entityManager->getRepository(Patient::class)->find($id);

    //     // Check if patient exists
    //     if (!$patient) {
    //         throw $this->createNotFoundException('No patient found for id ' . $id);
    //     }

    //     // Fetch all rendezvous related to this patient
    //     $rendezVous = $entityManager->getRepository(RendezV::class)->findBy(['patient' => $patient]);

    //     // Render the template with the rendezvous data
    //     return $this->render('patient/showRnv.html.twig', [
    //         'rendez_v' => $rendezVous,  // Pass all the rendezvous for the patient
    //         'patient' => $patient       // Optionally, pass the patient to display their details
    //     ]);
    // }

    #[Route('/getAll/{id}', name: 'app_rendez_v_show', methods: ['GET'])]
    public function show(int $id, EntityManagerInterface $entityManager): Response
    {
        $patient = $entityManager->getRepository(Patient::class)->find($id);
        if (!$patient) {
            throw $this->createNotFoundException('No patient found for id ' . $id);
        }

        $rendezVous = $entityManager->getRepository(RendezV::class)->findBy(['patient' => $patient]);

        return $this->render('patient/showRnv.html.twig', [
            'rendez_v' => $rendezVous,
            'patient' => $patient,
        ]);
    }



    #[Route('/{id}/edit', name: 'app_rendez_v_edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, RendezV $rendezV, EntityManagerInterface $entityManager): Response
    {
        $form = $this->createForm(RendezVType::class, $rendezV);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->flush();

            return $this->redirectToRoute('app_rendez_v_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->render('rendez_v/edit.html.twig', [
            'rendez_v' => $rendezV,
            'form' => $form,
        ]);
    }

    #[Route('/delete/{id}', name: 'app_rendez_v_delete', methods: ['POST'])]
    public function delete(int $id, EntityManagerInterface $entityManager): Response
    {
        $rendezV = $entityManager->getRepository(RendezV::class)->find($id);

        if (!$rendezV) {
            throw $this->createNotFoundException('No rendezvous found for id ' . $id);
        }

        $entityManager->remove($rendezV);
        $entityManager->flush();

        return $this->render("success.html.twig");
    }

    #[Route('/accepted_rendezvous', name: 'all_accepted_rendezvous', methods: ['GET'])]
    // public function showAcceptedRendezvous(RendezVRepository $rendezvousRepository): Response
    // {
    //     $acceptedRendezvous = $rendezvousRepository->findBy(['status' => 'accepted']);

    //     return $this->render('medecin/accepted_rn.html.twig', [
    //         'rendezvousList' => $acceptedRendezvous,
    //     ]);
    // }
    public function showAcceptedRendezvous(RendezVRepository $rendezvousRepository): Response
    {
        $acceptedRendezvous = $rendezvousRepository->findByStatus('accepted');

        return $this->render('medecin/accepted_rn.html.twig', [
            'rendezvousList' => $acceptedRendezvous,
        ]);
    }




}
