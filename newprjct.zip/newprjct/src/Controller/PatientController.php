<?php

namespace App\Controller;

use App\Entity\Patient;
use App\Entity\Medecin;
use App\Entity\Secretaire;
use App\Entity\RendezV;
use App\Form\PatientType;
use App\Repository\PatientRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Repository\SecretaireRepository;
use App\Entity\Acceptable;

#[Route('/patient')]
final class PatientController extends AbstractController
{

    private $entityManager;

    // Constructor to inject the EntityManager
    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }
    // List patients assigned to a specific secretary based on their ID
    #[Route('/patient/{id}', name: 'app_patient_index', methods: ['GET'])]
    public function index($id, PatientRepository $patientRepository, SecretaireRepository $secretaireRepository): Response
    {
        // Fetch the secretaire based on the ID
        $secretaire = $secretaireRepository->find($id);

        if (!$secretaire) {
            throw $this->createNotFoundException('Secretaire not found');
        }

        // Get all patients who have rendezvous with this secretaire
        $rendezvs = $secretaire->getRendezvs(); // Assuming 'rendezvs' is a collection of RendezV entities
        $patients = [];

        foreach ($rendezvs as $rendezv) {
            $patient = $rendezv->getPatient();
            if ($patient && !isset($patients[$patient->getId()])) {
                $patients[$patient->getId()] = $patient; // Use patient ID as key to ensure uniqueness
            }
        }

        return $this->render('patient/index.html.twig', [
            'patients' => array_values($patients), // Ensure the array has sequential keys
            'secretaire' => $secretaire,
        ]);
    }

    // List all patients and their rendezvous
    #[Route('/patient/allRnv/{id}', name: 'app_patient_all_rnv', methods: ['GET'])]
    public function allRendezvous($id, SecretaireRepository $secretaireRepository): Response
    {
        $secretaire = $secretaireRepository->find($id);

        if (!$secretaire) {
            throw $this->createNotFoundException('Secretaire not found');
        }

        $rendezvs = $secretaire->getRendezvs(); // Assuming 'getRendezvs' returns a collection of RendezV entities
        $rendezvousData = [];

        foreach ($rendezvs as $rendezv) {
            $patient = $rendezv->getPatient(); 
            $medecin = $rendezv->getMadecin(); 
            $dateRv = $rendezv->getDateRv();

            $rendezvousData[] = [
                'id' => $rendezv->getId(), 
                'patient' => $patient,
                'medecin' => $medecin,
                'date_rv' => $dateRv,
            ];
        }

        return $this->render('secretaire/showAllPRnv.html.twig', [
            'rendezvousData' => $rendezvousData,
            'secretaire' => $secretaire,
        ]);
    }

    // public function allRendezvous($id, SecretaireRepository $secretaireRepository): Response
    // {
    //     // Fetch the secretaire based on the ID
    //     $secretaire = $secretaireRepository->find($id);

    //     if (!$secretaire) {
    //         throw $this->createNotFoundException('Secretaire not found');
    //     }

    //     // Get all patients who have rendezvous with this secretaire
    //     $rendezvs = $secretaire->getRendezvs(); // Assuming 'rendezvs' is a collection of RendezV entities
    //     $patients = [];

    //     foreach ($rendezvs as $rendezv) {
    //         $patients[] = $rendezv->getPatient();
    //     }

    //     return $this->render('secretaire/showAllPRnv.html.twig', [
    //         'patients' => $patients,
    //         'secretaire' => $secretaire,
    //     ]);
    // }

    // Create new patient
    #[Route('/new', name: 'app_patient_new', methods: ['GET', 'POST'])]
    public function new(Request $request, EntityManagerInterface $entityManager): Response
    {
        $patient = new Patient();
        $form = $this->createForm(PatientType::class, $patient);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->persist($patient);
            $entityManager->flush();

            return $this->render("success.html.twig");
        }

        return $this->render('patient/new.html.twig', [
            'patient' => $patient,
            'form' => $form,
        ]);
    }

    // Show a single patient details
    #[Route('/{id}', name: 'app_patient_show', methods: ['GET'])]
    public function show(Patient $patient): Response
    {
        return $this->render('patient/show.html.twig', [
            'patient' => $patient,
        ]);
    }

    // Edit an existing patient's details
    #[Route('/{id}/edit', name: 'app_patient_edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, Patient $patient, EntityManagerInterface $entityManager): Response
    {
        $form = $this->createForm(PatientType::class, $patient);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->flush();

            return $this->render("success.html.twig");
        }

        return $this->render('patient/edit.html.twig', [
            'patient' => $patient,
            'form' => $form,
        ]);
    }

    // Delete a patient and their rendezvous with a medecin and secretaire
    #[Route('/{id}', name: 'app_patient_delete', methods: ['POST'])]
    public function delete(Request $request, Patient $patient, Medecin $medecin, Secretaire $secretaire, EntityManagerInterface $entityManager): Response
    {
        // Validate CSRF token
        if ($this->isCsrfTokenValid('delete'.$patient->getId(), $request->request->get('_token'))) {
            // Get the rendez_v records associated with the patient, medecin, and secretaire
            $rendezvRepository = $entityManager->getRepository(RendezV::class);
            $rendezvRecords = $rendezvRepository->findBy([
                'patient' => $patient,
                'medecin' => $medecin,
                'secretaire' => $secretaire,
            ]);

            // Remove the filtered rendez_v records
            foreach ($rendezvRecords as $rendezv) {
                $entityManager->remove($rendezv);
            }

            // Remove the patient record
            $entityManager->remove($patient);
            $entityManager->flush();
        }

        return $this->render("success.html.twig");
    }


    #[Route('/rendezvous/accept/{id}', name: 'rendezvous_accept')]
    public function acceptRendezvous(int $id): Response
    {
        $rendezvous = $this->entityManager->getRepository(RendezV::class)->find($id);
    
        if (!$rendezvous) {
            throw $this->createNotFoundException('Rendezvous non trouvé.');
        }
    
        // Mettre à jour le statut à "accepté"
        $rendezvous->setStatus('accepted');
        $this->entityManager->persist($rendezvous);
    
        $doctor = $rendezvous->getMadecin();
        $patient = $rendezvous->getPatient(); // Assurez-vous que cette méthode existe
    
        // Créer une nouvelle entrée dans la table Acceptable
        $acceptable = new Acceptable();
        $acceptable->setPatientname($patient->getName()); // Vérifiez que le patient a une méthode getName()
        $acceptable->setMedecinname($doctor->getName());
        $acceptable->setRendezvousdate($rendezvous->getDateRv()); // Vérifiez que cette méthode retourne une DateTime
    
        $this->entityManager->persist($acceptable);
    
        if ($doctor) {
            $message = sprintf('Le rendez-vous ID %d a été assigné au Dr. %s.', $id, $doctor->getName());
            $this->addFlash('success', $message);
        }
    
        // Supprimer le rendez-vous de la table `rendez_v`
        $this->entityManager->remove($rendezvous);
    
        $this->entityManager->flush();
        
        return $this->render("success.html.twig");
    }
    #[Route('/rendezvous/reject/{id}', name: 'rendezvous_reject')]
    public function rejectRendezvous(int $id): Response
    {
        $rendezvous = $this->entityManager->getRepository(RendezV::class)->find($id);
    
        if (!$rendezvous) {
            throw $this->createNotFoundException('Rendezvous non trouvé.');
        }
    
        // Supprimer le rendez-vous de la table `rendez_v`
        $this->entityManager->remove($rendezvous);
        
        $this->entityManager->flush();
    
        $this->addFlash('success', 'Le rendez-vous a été rejeté avec succès.');
    
        return $this->render("success.html.twig");
    }
        



}