<?php

namespace App\Controller;

use App\Entity\Medecin;
use App\Entity\Patient;
use App\Entity\Secretaire;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;

final class LoginController extends AbstractController
{
    private $entityManager;

    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    #[Route('/login', name: 'app_login')]
    public function index(): Response
    {
        return $this->render('login/index.html.twig', [
            'controller_name' => 'LoginController',
        ]);
    }

    
    #[Route('/checklogin', name: 'checklogin', methods: ['POST'])]
    public function checkLogin(Request $request): Response
    {
        // Get the form data (email and password)
        $email = $request->request->get('email');
        $password = $request->request->get('password');

        // Check Medecin credentials
        $medecin = $this->entityManager->getRepository(Medecin::class)->findOneBy(['email' => $email]);

        if ($medecin && $medecin->getPassword() === $password) {
            return $this->render('medecin/home.html.twig', [
                'email' => $medecin->getEmail(),
                'username' => $medecin->getName(),
            ]);
        }

        // Check Patient credentials
        $patient = $this->entityManager->getRepository(Patient::class)->findOneBy(['email' => $email]);
        $doctors = $this->entityManager->getRepository(Medecin::class)->findAll();
        $secretaires = $this->entityManager->getRepository(Secretaire::class)->findAll();
        
        if ($patient && $patient->getPassword() === $password) {
            return $this->render('patient/home.html.twig', [
                'email' => $patient->getEmail(),
                'username' => $patient->getName(),
                'id' => $patient->getId(),
                'doctors' => $doctors,
                'secretairas' => $secretaires
            ]);
        }

        // Check Secretaire credentials
        $secretaire = $this->entityManager->getRepository(Secretaire::class)->findOneBy(['email' => $email]);
        $doctorssec = $this->entityManager->getRepository(Medecin::class)->findAll();
        $patientsec = $this->entityManager->getRepository(Patient::class)->findAll();
        if ($secretaire && $secretaire->getPassword() === $password) {
            return $this->render('secretaire/home.html.twig', [
                'email' => $secretaire->getEmail(),
                'id' => $secretaire->getId(),
                'patient' => $patientsec,
                'doctors' => $doctors
            ]);
        }

        // If no match is found, return an error (optional)
        return $this->render('login/index.html.twig', [
            'error' => 'Invalid credentials, please try again.',
        ]);
    }

}
